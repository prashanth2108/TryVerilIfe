import React from 'react';

import './DonorValidation.css';

class DonorValidation extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className='donorvalidation_wrapper'>


           <h1>Hi</h1>
            </div>
        );
    }
}

export default DonorValidation;
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap';
import './SearchDonorByLocation.css';

class SearchDonorByLocation extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (

            
            <form>
    <br/>
    <br/>
            
            <div className="row">
            <div class="dropdown col-sm-1">
                <button  class="btn btn-secondary dropdown-toggle" type="text" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Select Blood Group
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
             </div>
             <div class="dropdown col-sm-2">
                <button  class="btn btn-secondary dropdown-toggle" type="text" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Select Blood Group
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
             </div>
            
            
            <button class="col-sm-5" type="submit" class="btn btn-primary">Submit</button>
            </div>

            </form>
           
          
            
            
        );
    }
}

export default SearchDonorByLocation;
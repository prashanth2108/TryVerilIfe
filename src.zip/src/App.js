import React from 'react';
import logo from './logo.svg';
import './App.css';
import DonorRegister from './DonorRegister/DonorRegister.react';
import PatientRegister from './PatientRegister/PatientRegister.react';
import Login from './Login/Login.react';
import Buttonss from './Buttonss/Buttonss.react';
import SearchDonorByLocation from './SearchDonorByLocation/SearchDonorByLocation.react';

function App() {
  return (
    <div className="App">
     {/* <Buttonss/> */}
     <SearchDonorByLocation/>
     {/* <DonorRegister/> */}
    </div>
  );
}

export default App;
